#! /usr/bin/env python

import ctypes as ct
import ctypes.util


lib = ct.util.find_library("c")
libc = ct.cdll.LoadLibrary(lib)


libc.drand48.restype = ct.c_double
libc.drand48.argtypes = None 

xx = [libc.drand48(None) for i in range(100)]

print xx
print len(xx)

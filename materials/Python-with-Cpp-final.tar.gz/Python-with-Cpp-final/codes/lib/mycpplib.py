# ===========================================================================
import time
import sys
import math
import os

import ctypes
# ===========================================================================
# Initialization 
# ===========================================================================

# Note that we have to use the path reltive to the master / top script, 
# not relative to this module file (the .so file is in this same directory).
libmy = ctypes.cdll.LoadLibrary("lib/libmycpp.so")

# ===========================================================================
# Call to a simple implementation of check_overlaps() function with
# preallocated python arrays.
# ===========================================================================
def check_overlaps(conf):
	n = len(conf.atoms)

	# Set the input and return types for our C++ function
        # according to the design.
	libmy.overlaps.restype = ctypes.c_int 
	libmy.overlaps.argtypes = [ \
                   ctypes.POINTER(ctypes.c_double), \
                   ctypes.POINTER(ctypes.c_double), \
                   ctypes.POINTER(ctypes.c_double), \
                   ctypes.POINTER(ctypes.c_double), \
                   ctypes.c_int, \
                   ctypes.c_int, \
                   ctypes.POINTER(ctypes.c_int), \
                   ctypes.POINTER(ctypes.c_int), \
                   ctypes.POINTER(ctypes.c_double) ]

    # Use a euristic, make the buffer twice the number of atoms.
	max_nolaps = 2 * n 

	# Prepare the input arrays.
	xx = (ctypes.c_double * n)()
	yy = (ctypes.c_double * n)()
	zz = (ctypes.c_double * n)()
	rr = (ctypes.c_double * n)()

	for i in range(n):
		xx[i] = conf.atoms[i].x
		yy[i] = conf.atoms[i].y
		zz[i] = conf.atoms[i].z
		rr[i] = conf.atoms[i].radius
		

	while True: 
		ii = (ctypes.c_int * max_nolaps)()
		jj = (ctypes.c_int * max_nolaps)()
		dd = (ctypes.c_double * max_nolaps)()

		nolaps = libmy.overlaps(xx, yy, zz, rr, n, \
                                max_nolaps, ii, jj, dd)

		# If the number of overlaps is less than max_nolaps then we are done.
		if nolaps <= max_nolaps: break

		# Repeat the search with increased buffers.
		max_nolaps = nolaps

	# Repackage the output into expected format.
	overlaps = [(ii[k], jj[k], dd[k]) for k in range(nolaps)]

	return overlaps

# ===========================================================================
# Call to a complex implementation of check_overlaps() function
# with internal memory allocation.
# ===========================================================================
def check_overlaps_mem(conf):
	n = len(conf.atoms)

	# Set the input and return types for our C++ function
        # according to the design.
        libmy.overlaps_mem.restype = ctypes.c_int
        libmy.overlaps_mem.argtypes = [ \
                   ctypes.POINTER(ctypes.c_double), \
                   ctypes.POINTER(ctypes.c_double), \
                   ctypes.POINTER(ctypes.c_double), \
                   ctypes.POINTER(ctypes.c_double), \
                   ctypes.c_int, \
                   ctypes.POINTER(ctypes.POINTER(ctypes.c_int)), \
                   ctypes.POINTER(ctypes.POINTER(ctypes.c_int)), \
                   ctypes.POINTER(ctypes.POINTER(ctypes.c_double))]

	# Prepare the input arrays.
	xx = (ctypes.c_double * n)()
	yy = (ctypes.c_double * n)()
	zz = (ctypes.c_double * n)()
	rr = (ctypes.c_double * n)()

	for i in range(n):
		xx[i] = conf.atoms[i].x
		yy[i] = conf.atoms[i].y
		zz[i] = conf.atoms[i].z
		rr[i] = conf.atoms[i].radius
		

	# Arrays of pointers for output buffers, size = 1;
	# Trick to to overcome C argument-by-value passing.
	pii = (ctypes.POINTER(ctypes.c_int) * 1)()
	pjj = (ctypes.POINTER(ctypes.c_int) * 1)()
	pdd = (ctypes.POINTER(ctypes.c_double) * 1)()

	nolaps = libmy.overlaps_mem(xx, yy, zz, rr, n, pii, pjj, pdd)

        # Read the pointers to the arrays allocaed during the search.
	pi = pii[0]
	pj = pjj[0]
	pd = pdd[0]

	# Repackage the output into expected format.
	overlaps = [(pi[k], pj[k], pd[k]) for k in range(nolaps)]

        # Release the allocated memory using our C++ funciton.
	libmy.free_mem(pi, pj, pd)
	return overlaps

# ===========================================================================

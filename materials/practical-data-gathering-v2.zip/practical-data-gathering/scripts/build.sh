#!/bin/bash

docker build ../image -t minpy:v1
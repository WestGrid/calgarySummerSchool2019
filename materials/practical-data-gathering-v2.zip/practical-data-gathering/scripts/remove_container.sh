#!/bin/bash

docker container rm notebook
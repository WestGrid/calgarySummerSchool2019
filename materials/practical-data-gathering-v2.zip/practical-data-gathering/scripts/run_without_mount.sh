#!/bin/bash

docker run -it -p 8080:8888 --name notebook minpy:v1 
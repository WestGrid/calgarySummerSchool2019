#! /usr/bin/env python
import numpy

# Resolution.
n =  500
# Dimensions.
nx, ny, nz = 1 * n, 2 * n, 3 * n

print "Integrating over %d elements..." % (nx * ny * nz)

dl = 1.0 / n
dV = dl**3

# "f" works faster
xxx = numpy.ones((nx, ny, nz), dtype="d")
V = numpy.sum(xxx * dV)

print "V = %f" % V 



#! /usr/bin/env python
import numpy

x = 0
n =  50000000

xx = numpy.arange(n, dtype="d")
x = numpy.sum(numpy.sqrt(xx)) / n

print "Result = %f" % x 



# Read a text file and count the numbers of each character.
fname = "prob4.py"
print "Reading '%s' file..." % fname

txt = open(fname).read()

counts = {}

for c in txt:

    if counts.has_key(c): counts[c] += 1
    else: counts[c] = 1

kk = counts.keys()
kk.sort()

count = 0

for k in kk:
    key = str(k)

    # Invisible characters.
    if k == '\n': key = "\\n"
    elif k == '\t': key = "\\t"

    print "%s : %d" % (key, counts[k])
    count += counts[k] 

print "Total: %s characters." % count


        

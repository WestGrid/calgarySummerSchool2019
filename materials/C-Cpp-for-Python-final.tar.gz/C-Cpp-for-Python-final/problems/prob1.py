#! /usr/bin/env python
import math

x = 0
n =  50000000

for i in range(n):

        x += math.sqrt(float(i))

x /= float(n)

print "Result = %f" % x 



#! /usr/bin/env python
# ==========================================================
class my_class:

        def __init__(self, v):
            self.v = v

        def __add__(self, x):
            self.v += x
            return self

        def __repr__(self):
            return "my_class object [value = %g]" % self.v


# ==========================================================
obj = my_class(10.)
print obj

obj += 1.
print obj

# ==========================================================


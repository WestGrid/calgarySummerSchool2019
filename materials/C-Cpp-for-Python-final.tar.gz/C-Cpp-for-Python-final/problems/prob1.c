#include<stdio.h>
#include<math.h>

int main() {

	int i;
	int n = 50000000;
	double x = 0;

	for(i = 0; i < n; i++) {
		x += sqrt((double)i);
	}

	x /= (double)n;

	printf("Result = %f\n", x);
}

#include<iostream>
using namespace std;

int main() {

	// Resolution.
	int n(500);
	// Dimensions.
	int nx(1 * n), ny(2 * n), nz(3 * n);

	cout << "Integrating over " << nx * ny * nz << " elements..." << endl;

	double dl(1.0 / n);
	double dV(dl * dl * dl);

	double V(0.0);

	for(int ix = 0; ix < nx; ix++) {
		for(int iy = 0; iy < ny; iy++) {
			for(int iz = 0; iz < nz; iz++) {
				V += dV;
			}
		}
	}
	cout << "V = " << V << endl;
}

#include<iostream>

using namespace std;

class my_class {
public:
	double v;

	my_class(double x): v(x) {}

	void operator+= (double x) { v += x; }
};

ostream& operator<< (ostream& s, const my_class& x) {
	s << "my_class object [value = " << x.v << "]";
	return s;
}


int main(){
	my_class obj(10);
	cout << obj << endl;

	obj += 1.0;
	cout << obj << endl;
}

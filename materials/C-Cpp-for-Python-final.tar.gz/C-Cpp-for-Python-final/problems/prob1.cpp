#include<iostream>
#include<cmath>

using namespace std;

int main() {

	int n(50000000);
	double x(0);

	for(int i = 2; i < n; i++) {
		x += sqrt(double(i));
	}

	x /= double(n);

	cout << "Result = " << x << endl;
}

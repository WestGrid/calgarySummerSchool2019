#include<iostream>
#include<fstream>
#include<string>
#include<map>

using namespace std;
// Reading a text file and counting the numbers of characters.

int main(){
	string fname = "prob4.py";
	cout << "Reading '" << fname << "' file..." << endl;

	ifstream file(fname, ios::in);
	map<char,int> counts;

	// Collect data.
	while(true) {
		char c = file.get();
		if(file.eof()) break;

		if(counts.count(c) == 0) counts[c] = 1;
		else counts[c]++;

	}
	file.close();

	// Output counts.
	map<char,int>::iterator it;
	int count = 0;

	for(it = counts.begin(); it != counts.end(); it++) {
		char c = it->first;
		string key(&c, 1);

		if(c == '\n') key = "\\n";
		else if(c == '\t') key = "\\t";

		cout << key << " : " << it->second << endl;
		count += it->second;
	}
	cout << "Total: " << count << " characters." << endl;
}

#include<stdio.h>

int main() {

	int ix, iy, iz;

	/* Resolution */
	int n = 500;
	/* Dimensions */
	int nx = 1 * n, ny = 2 * n, nz = 3 * n;

	printf("Integrating over %d elements...\n", nx * ny * nz);

	double dl = 1.0 / n;
	double dV = dl * dl * dl;
	double V = 0.0;

	for(ix = 0; ix < nx; ix++) {
		for(iy = 0; iy < ny; iy++) {
			for(iz = 0; iz < nz; iz++) {
				V += dV;
			}
		}
	}
	printf("V = %f\n", V);
}

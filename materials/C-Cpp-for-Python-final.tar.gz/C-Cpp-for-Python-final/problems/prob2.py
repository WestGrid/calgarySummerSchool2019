#! /usr/bin/env python

# Resolution.
n =  500

# Dimentions.
nx, ny, nz = 1 * n, 2 * n, 3 * n

print "Integrating over %d elements..." % (nx * ny * nz)

dl = 1.0 / n
dV = dl**3

V = 0

for ix in range(nx):
    for iy in range(ny):
        for iz in range(nz):
                V += dV
    
print "Volume = %f" % V



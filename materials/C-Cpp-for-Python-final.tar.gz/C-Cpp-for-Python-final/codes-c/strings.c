#include <stdio.h>

/* Strings. */
int main(){
	int i, j;

	char s1[] = {'s', 't', 'r', 'i', 'n', 'g'};

	char s2[] = "string";

	char s3[] = {'s', 't', 'r', 'i', 'n', 'g', '\0'};

	char s4[100] = "string";


	puts("-------------------------------------------");
	printf("s1 length = %lu \n", sizeof(s1));

	for(i = 0; i < sizeof(s1); i++) printf("%c", s1[i]);
	printf("\n");

	puts("-------------------------------------------");
	printf("s2 length = %lu \n", sizeof(s2));

	printf("%s\n", s2);

	printf("\n");
	for(i = 0; i < sizeof(s2); i++) printf("%d  %x  %c\n", i, s2[i], s2[i]);

	puts("-------------------------------------------");
	printf("s3 length = %lu \n", sizeof(s3));

	printf("%s\n", s3);

	puts("-------------------------------------------");
	printf("s4 length = %lu \n", sizeof(s4));

	printf("%s\n", s4);
} 

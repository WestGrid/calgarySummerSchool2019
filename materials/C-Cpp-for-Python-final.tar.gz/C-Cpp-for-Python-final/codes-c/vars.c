#include <stdio.h>

/* Variables. */
int main(){
	int i;
	int n, m = 0;
	printf("Integers: %d, %d, %d\n", i, n, m);

	unsigned int k, l = 0;
	printf("Unsigned integers: %u, %u\n", k, l);

	float x = 5.0;
	double y =x, z;
	printf("Real numbers: %f, %e, %g\n", x, y, z);

	char a = 'a';
	char b = '!', c = '?';
	printf("Characters: %c, %c, %c\n", a, b, c);
} 

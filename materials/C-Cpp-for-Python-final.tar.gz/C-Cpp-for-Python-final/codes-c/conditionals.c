#include <stdio.h>

/* Conditional statement. */
int main(){
	int i = 5, j = 8;

	if (i < j) printf("i is less than j.\n");
	printf("\n");

	i += 4;
	if (i < j) {
		printf("i is less than j.\n");
		printf("i = %d, j = %d\n", i, j);
	} else {
		printf("i is not less than j.\n");
		printf("i = %d, j = %d\n", i, j);
	}

	printf("\n");
	printf("Value = %d\n", 4 == 4);
	printf("Value = %d\n", 4 != 4);

	if(-3) printf("Negative is true.\n");
	if(0) printf("Zero is true\n");
	if(3) printf("Positive is true\n");
} 

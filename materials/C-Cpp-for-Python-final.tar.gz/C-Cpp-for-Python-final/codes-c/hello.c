#include <stdio.h>

/* Our first program. */
int main(){

	printf("Hello World!\n");
	return 0;
} 

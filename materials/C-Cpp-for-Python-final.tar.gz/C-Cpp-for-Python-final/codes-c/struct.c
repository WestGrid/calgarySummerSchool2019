#include <stdio.h>

/* Structures. */
/* ------------------------------------------------------------------------ */
struct vec3d {
	double x, y, z;
};

typedef struct vec3d vector3d;

typedef struct { 
	double w;
	vector3d v;
} quaternion;

/* ------------------------------------------------------------------------ */
void set_vector(double x, double y, double z, vector3d *vptr) {
	vptr->x = x;
	vptr->y = y;
	vptr->z = z;
}

/* ------------------------------------------------------------------------ */
int main(){

	struct vec3d v1;
	vector3d v2;
	vector3d v3 = {4, 5, 6};
	vector3d *vptr = &v3;

	quaternion q1 = {1, 2, 3, 4};

	set_vector(1.0, 2.0, 3.0, &v1);
	printf("Vector 1: (%g, %g, %g)\n", v1.x, v1.y, v1.z);

	v2 = v1;
	printf("Vector 2: (%g, %g, %g)\n", v2.x, v2.y, v2.z);

	printf("Vector 3: (%g, %g, %g)\n", v3.x, v3.y, v3.z);

	printf("Vector pointer: (%g, %g, %g)\n", vptr->x, vptr->y, vptr->z);

	printf("Quaternion 1: [%g, (%g, %g, %g)]\n", q1.w, q1.v.x, q1.v.y, q1.v.z);

	q1.v = v3;
	printf("Quaternion 1: [%g, (%g, %g, %g)]\n", q1.w, q1.v.x, q1.v.y, q1.v.z);
} 

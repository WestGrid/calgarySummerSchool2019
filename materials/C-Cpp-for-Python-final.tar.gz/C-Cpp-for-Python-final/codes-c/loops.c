#include<stdio.h>

/* Loops */
int main(){
	int i, j;

	puts("--------------------------------------");
	/* known number of iterations, usually. */
	for(i = 0; i < 5; i++){
		printf("i = %2d\n", i);
	}
	
	puts("--------------------------------------");
	/* loop with a pre-condition. */
	i = 0;
	while(i++ < 5) {
		printf("i = %2d\n", i);
	}

	puts("--------------------------------------");
	/* loop with a post-condition. */
	i = 0;
	do {
		printf("i = %2d\n", i);
	} while(++i < 5);

	puts("--------------------------------------");
	/* loop with continue, break. */
	i = 0;
	do {
		if(i == 1) continue;
		if(i == 4) break;

		printf("i = %2d\n", i);
	} while(++i < 5);


	puts("--------------------------------------");
	/* For loop with comma operators. */
	for(i = 0, j = 6; i < j; i++, j--){
		printf("i = %2d, j = %2d\n", i, j);
	}
}


#include <stdio.h>

/* Switch statement. */
int main(){
	int i;

	for(i = 0; i < 10; i++){

		switch(i) {
			case 1: puts("i is 1.");
			       break;
			case 2: {
					puts("i is 2.");
					puts("i is 2.");
				}
				break;
			case 3: puts("i is 3.");
			case 4: puts("i is 4 or 3.");
				break;

			default: puts("i is not 1, 2, 3, or 4.");
		}
	}
} 

#include <stdio.h>

/* Pointers */
int main(){
	char s1[] = "Array string.";
	char *s2 = "Pointer string.";

	printf("\n");
	puts(s1);
	puts(s2);

	printf("\n");
	printf("sizeof(s1) = %lu\n", sizeof(s1));
	printf("sizeof(s2) = %lu\n", sizeof(s2));

	printf("\n");
	printf("s1 = %p,  s1[0] = %c,  &s1[0] = %p\n", s1, s1[0], &s1[0]);
	printf("s2 = %p,  s2[0] = %c,  &s2[0] = %p\n", s2, s2[0], &s2[0]);

	double x = 3.14;
	int i = 123;

	printf("\n");
	printf("x = %g, &x = %p\n", x, &x);
	printf("i = %d, &i = %p\n", i, &i);

	double *xp = &x;
	int *ip = &i;

	printf("\n");
	printf("xp = %p, *xp = %g,  &xp = %p\n", xp, *xp, &xp);
	printf("ip = %p, *ip = %d,  &ip = %p\n", ip, *ip, &ip);

	printf("\n");
	/* For arrays s1 == &s1, but not for pointers. */
	/* Array is a constant reference, while pointer is a variable reference. */
	printf("s1 = %p,  *s1 = %c,  &s1 = %p\n", s1, *s1, &s1);
	printf("s2 = %p,  *s2 = %c,  &s2 = %p\n", s2, *s2, &s2);


	//s1 = s2;   /* Compilation error. */
	s2 = s1;   /* Works, but we loose access to the s2 string */

	printf("\n");
	printf("s1 = %s\n", s1);
	printf("s2 = %s\n", s2);
} 

#! /bin/bash

gcc main_c.c -o main_c.x

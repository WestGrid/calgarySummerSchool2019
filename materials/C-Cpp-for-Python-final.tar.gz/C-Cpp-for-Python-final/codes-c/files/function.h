#ifndef MYFUNC_H
#define MYFUNC_H

void my_function(void);

#endif

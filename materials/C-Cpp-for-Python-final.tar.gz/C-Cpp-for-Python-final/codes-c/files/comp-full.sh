#! /bin/bash

gcc main_full.c -o main_full.x

#include <stdio.h>
/* Complex code. */

#include "function.h"

int main(){

	printf("Main code.\n");

	my_function();
} 

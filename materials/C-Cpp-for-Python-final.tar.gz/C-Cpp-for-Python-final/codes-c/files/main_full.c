#include <stdio.h>
/* Complex code. */

void my_function(void) {
	printf("My function.\n");
}

int main(){

	printf("Main code.\n");

	my_function();
} 

#include <stdio.h>
/* Complex code. */

#include "function.c"

int main(){

	printf("Main code.\n");

	my_function();
} 

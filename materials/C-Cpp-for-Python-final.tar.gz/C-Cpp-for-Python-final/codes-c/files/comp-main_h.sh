#! /bin/bash

gcc -c "main_h.c"
gcc -c "function.c"

gcc "main_h.o" "function.o" -o main_h.x

#ifndef MYFUNC
#define MYFUNC

#include <stdio.h>

void my_function(void) {
	printf("My function.\n");
}

#endif

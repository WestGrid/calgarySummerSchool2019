#include <stdio.h>

/* Arrays. */
int main(){
	int i, j;

	double xx[100];
	char cc[60];
	float yy[10];

	float zz[] = {1.0, 3.14, 2.72, 6.03e23};

	puts("-------------------------------------------");
	int nn[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

	for(i = 0; i < 10; i++) {
		printf("[%d] = %d\n", i, nn[i]);
	}

	puts("-------------------------------------------");
	int mm[6] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

	for(i = 0; i < 10; i++) {
		printf("[%d] = %d\n", i, mm[i]);
	}

	puts("-------------------------------------------");
	int ll[10];

	for(i = 0, j = 9; i < 10; i++, j--) ll[j] = nn[i];

	for(i = 0; i < 10; i++) printf("[%d] = %d\n", i, ll[i]);
} 

#include <stdio.h>
#include <math.h>

/* --------------------- Functions ------------------------ */
double my_compute(double x, double y) { 
	return sin(x) + cos(y);
}

void zero_string(char txt[], int len) {
	int i;
	for(i = 0; i < len; i++) txt[i] = '\0';
}

int my_round(double);

/* -------------------------------------------------------- */
int main(){

	double y;
	char message[] = "Test message.";

	y = my_compute(0.5, 1.5);
	printf("%g\n", y);

	printf("\"%s\"\n", message);

	zero_string(message, sizeof(message));
	printf("\"%s\"\n", message);

	printf("Round of %g is %d.\n", y, my_round(y));
} 

/* -------------------------------------------------------- */
int my_round(double x) {
	return (int)(x + 0.5);
}

/* -------------------------------------------------------- */

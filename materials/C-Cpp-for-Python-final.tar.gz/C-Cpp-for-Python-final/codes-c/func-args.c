#include <stdio.h>
/* Passing function argurments. */

typedef struct {
	char name[10];
	double data[5];
} named;

void function1(double x, double *y, const double *z) {

	printf("sizeof(x) = %lu\n", sizeof(x));
	printf("sizeof(y) = %lu\n", sizeof(y));
	printf("sizeof(z) = %lu\n", sizeof(z));

	printf("x addr = %p\n", &x);
	printf("y addr = %p\n",  y);
	printf("z addr = %p\n",  z);
}

void function2(char xx[], const char yy[]) {

	printf("sizeof(xx) = %lu\n", sizeof(xx));
	printf("sizeof(yy) = %lu\n", sizeof(yy));

	printf("xx addr = %p\n", xx);
	printf("yy addr = %p\n", yy);
}

void function3(char *xp, const char *yp) {

        printf("sizeof(xp) = %lu\n", sizeof(xp));
        printf("sizeof(yp) = %lu\n", sizeof(yp));

        printf("xp addr = %p\n", xp);
        printf("yp addr = %p\n", yp);
}

void function4(named x, named *y) {

	printf("sizeof(x) = %lu\n", sizeof(x));
	printf("sizeof(y) = %lu\n", sizeof(y));

	printf("x addr = %p\n", &x);
	printf("y addr = %p\n", y);
}

int main(){
	int i, j;

	double v = 100.0;
	printf("v addr = %p\n", &v);
	printf("\n");

	function1(v, &v, &v);
	printf("\n");

	char vv[] = "argument string";

	printf("vv addr = %p\n", vv);
	printf("\n");

	function2(vv, vv);
	printf("\n");
	function3(vv, vv);
	printf("\n");

	named info = {"Venus", 1.0, 2.0, 3.0, 4.0, 5.0};
	printf("sizeof(info) = %lu\n", sizeof(info));
	printf("info addr = %p\n", &info);
	printf("\n");

	function4(info, &info);
	printf("\n");
} 

#include <stdio.h>

/* Operators. */
int main(){
	int i = 5, j = 8;
	int n = i + j;
	printf("Integers: %d, %d, %d\n", n, i, j);
	printf("Difference: %d\n", i - j);

	double x = 3.14, y = 20.2, z;
	z = y * x;

	printf("Z = %g\n", z);

	z *= 3.;
	printf("Z = %g\n", z);

	printf("i   = %d\n", i);
	printf("i++ = %d\n", i++);
	printf("++i = %d\n", ++i);
	printf("i   = %d\n", i);
} 

#include <stdio.h>
#include <stdlib.h>

/* Read a file. */

int main(){
	char fname[] = "vars.c";

	FILE *fptr = fopen(fname, "r");

	/* Determine the size of the file. */
	fseek(fptr, 0L, SEEK_END);
	size_t fsize = ftell(fptr);
	fseek(fptr, 0L, SEEK_SET);

	printf("fsize = %lu\n", fsize);

	/* Allocate enought memory to fit the file's data. */
	char *data = (char *)malloc(sizeof(char) * fsize);

	/* Read the file into the allocated buffer. */
	fread(data, sizeof(char), fsize, fptr);

	/* Show the data. */
	puts(data);
	fclose(fptr);

	/* Write a file. */
	fptr = fopen("vars2.c", "w");
	fwrite(data, sizeof(char), fsize, fptr);
	fclose(fptr);

	/* Release allocated memory. */
	free(data);
} 


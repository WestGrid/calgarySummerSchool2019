#include <stdio.h>

/* Pointer arithmetics  */
int main(){
	double xx[] = {1.1, 2.2, 3.3, 4.4, 5.5};

	//double *xxp = &xx[0];
	double *xxp = xx;

	size_t i;

	printf("\n");
	for(i = 0; i < 5; i++)
		printf("%lu  %g  %g  %g  %g\n", i, xx[i], xxp[i], *(xx + i), *(xxp + i));

	printf("\n");
	for(i = 0; i < 5; i++) printf("%lu  %p  %p\n", i, &xxp[i], xxp + i);

	printf("\n");
	for(xxp = xx; xxp < (xx + 5); xxp++) printf("%p  %g\n", xxp, *xxp);
} 

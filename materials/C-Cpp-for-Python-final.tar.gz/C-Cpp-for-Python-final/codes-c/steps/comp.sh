#! /bin/bash

cpp hello.c -o hello_pp.c

gcc -S hello_pp.c -o hello.asm

as hello.asm -o hello.o 

#./link.sh hello.o
gcc hello.o -o hello.x

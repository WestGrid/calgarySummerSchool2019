# /bin/bash

INPUT=$1

ld \
	-dynamic-linker /lib64/ld-linux-x86-64.so.2 \
	-pie \
	-o hello.x \
	/usr/lib/x86_64-linux-gnu/Scrt1.o \
	/usr/lib/x86_64-linux-gnu/crti.o \
	/usr/lib/gcc/x86_64-linux-gnu/6/crtbeginS.o \
	-L/usr/lib/gcc/x86_64-linux-gnu/6 \
	$INPUT \
	-lgcc -lc \
	/usr/lib/gcc/x86_64-linux-gnu/6/crtendS.o \
	/usr/lib/x86_64-linux-gnu/crtn.o


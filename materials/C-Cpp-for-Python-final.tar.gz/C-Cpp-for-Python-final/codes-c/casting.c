#include <stdio.h>
#include <stdlib.h>

/* Casting */

int main(){
	int i, n;
	double x;

	i = 2.2;
	n = 10;

	x = i / n;
	printf("x = %g\n", x);

	x = (double)i / n;
	printf("x = %g\n", x);

	/* malloc(...) returns (void *) type. */
	int *buf = (int *)malloc(sizeof(int) * 100);

	char *cp = (char *) buf;

	buf[0] = 1234;
	printf("dp[0] = %d\n", buf[0]);

	/* Characters are converted to (int) and then formatted with "%d". */
	for(i = 0; i < sizeof(int); i++) printf("%p  %d  %d\n", cp + i, i, cp[i]);

	printf("%d\n", 256 + cp[0] + cp[1] * 256);
} 

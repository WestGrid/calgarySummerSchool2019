#include <stdio.h>
#include <string.h>

/* String Functions */

/* Length of str.  */
//size_t strlen(const char *str);

/* Copy string src to dst.  */
//char *strcpy(char *dest, const char *src);

/* returns a pointer to the first occurrence of the character c in the string str, 
  NULL if the character is not found. */
//char *strchr(const char *str, int c);

/* Add string src to the end of dst.  */
//char *strcat(char *dest, const char *src);

/* Compares str1 to str2, return <0, 0, or >0, if less, equal, or greater.  */
//int strcmp(const char *str1, const char *str2);

/* returns a pointer to the first token found in the string. 
   A null pointer is returned if there are no tokens left to retrieve.  */
//char *strtok(char *str, const char *delim);

int main(){

	char msg1[] = "Error message.";
	char msg2[] = "Very long message for testing purposes.";

	char buf1[100], buf2[200];

	printf("Msg1 length = %lu\n", strlen(msg1));
	printf("Msg2 length = %lu\n", strlen(msg2));
	printf("\n");

	strcpy(buf1, msg1);
	printf("Buf1 length = %lu\n", strlen(buf1));

	if(strcmp(msg1, msg2) == 0) puts("msg1 and msg2 are equal.");
	else puts("msg1 and msg2 are not equal.");

	if(strcmp(msg1, buf1) == 0) puts("msg1 and buf1 are equal.");
	else puts("msg1 and buf1 are not equal.");

	printf("Sizeof msg1 = %lu\n", sizeof(msg1));
	printf("Sizeof buf1 = %lu\n", sizeof(buf1));
} 

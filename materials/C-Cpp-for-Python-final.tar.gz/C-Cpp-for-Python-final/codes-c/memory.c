#include <stdio.h>
#include <stdlib.h>

/* Memory allocation */

int main(){
	int i;
	int n = 10;

	/* Allocate memory at compilation time. */
	int buf1[n];

	/* Allocate memory at run time. */
	int *buf2 = (int *)malloc(sizeof(int) * n);

	double *buf3 = (double *)malloc(sizeof(double) * n);

	/* Initialize the buffers */
	for(i = 0; i < n; i++) { 
		buf1[i] = i + 10;
		buf2[i] = i + 20; 
		buf3[i] = i + 30;
	}

	/* Read the buffers */
	for(i = 0; i < n; i++) printf("%d  %d  %d  %.1f\n", i, buf1[i], buf2[i], buf3[i]);

	/* Free allocated memory. */
	free(buf2);
	free(buf3);
} 

#include <stdio.h>

/* Command Line Arguments. */
int main(int argc, char *argv[]){
	int i;

	printf("Arguments given: %d\n", argc);

	for(i = 0; i < argc; i++) {
		printf("Argument %d: \"%s\"\n", i, argv[i]);
	}

	/* check the exit code with
	 $ echo $?
	 right after executing the code. */
	return argc;
} 

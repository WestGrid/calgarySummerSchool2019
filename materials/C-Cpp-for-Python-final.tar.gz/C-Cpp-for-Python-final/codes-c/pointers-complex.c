#include <stdio.h>

/* Complex Pointers  */
/* Read this: http://unixwiz.net/techtips/reading-cdecl.html */

int main(){
	int i;

	/* The dimentions must be given. Initialization by rows. */
	double xx[2][3] = {{1.1, 2.2, 3.3}, {4.4, 5.5, 6.6}};
	printf("xx[0][1] = %g\n", xx[0][1]);

	/* Or a sequence filling by rows. */
	double yy[3][2] = {6.1, 5.2, 4.3, 3.4, 2.5, 1.6};

	/* Initialize to 0, only 0 works. */
	double zz[4][4] = {0.0};

	/* Element [0][0] is 3.0, the rest is 0. */
	double vv[5][5] = {3.0};

	/* Array of tables of rows of elements. */
	int mmm[5][6][7];


	/* pointer to double (array) */
	double *xp;
	xp = xx[1];

	printf("\n");
	for(i = 0; i < 3; i++) printf("%d  %g\n", i, xp[i]);
	
	/* pointer to array[2] of doubles */
	double (*yyp)[2];
	yyp = yy;

	printf("\n");
	for(i = 0; i < 2; i++) printf("%d  %g\n", i, (*yyp)[i]);

	printf("\n");
	for(i = 0; i < 3; i++) printf("%d  %g\n", i, *(yyp + i)[0]);

	/* Array of 2 pointers to double */
	double *ppd[2];

	/* Pointer to a pointer to double */
	double **dpp;

	/* double *dpa[];  	Invalid declaration. Only arguments can be of *ap[] type. */
} 

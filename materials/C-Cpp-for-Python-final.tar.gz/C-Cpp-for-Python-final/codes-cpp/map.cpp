#include <iostream>
#include<vector>
#include<string>
#include<map>

using namespace std;
// STL Map class.

int main(){
	map<string,int> dict;

	dict["One"] = 1;
	dict["Two"] = 2;
	dict["Tree"] = 3;
	dict["Four"] = 4;
	dict["Five"] = 5;

	string key("Four");
	int x = dict[key];
	cout << key << " is " << x << endl;

	key = "Seven";
	x = dict[key];
	cout << key << " is " << x << endl;
	cout << endl;


	vector<string> keys;
	map<string,int>::iterator it;

	for(it = dict.begin(); it != dict.end(); it++)
		keys.push_back(it->first);


	for(int i = 0; i < keys.size(); i++)
		cout << keys[i] << " = " << dict[keys[i]] << endl;

	cout << endl;

	if(dict.count("Two") > 0) cout << "Two is in the dict." << endl;
	if(dict.count("Six") == 0) cout << "Six is not in the dict." << endl;

	cout << endl;

	it = dict.find("Two");
	if(it != dict.end()) cout << "Two is " << it->second << endl;
} 

#include <iostream>
#include<string>
#include<cstdio>

using namespace std;
// STL string class.

int main(){

	string s1;
	string s2("string 2");

	char s[] = "C string";
	string s3(s);

	// Additions 
	s1 = s2 + " and " + s3;

	cout << "String 1 '" << s1 <<  "'" << endl;
	cout << "String 2 '" << s2 <<  "'" << endl;
	cout << "String 3 '" << s3 <<  "'" << endl;
	cout << endl;

	// Both work 
	int n = s1.size();
	int m = s1.length();

	cout << "s1 length is " << n << " or " << m << endl;
	cout << endl;

	s1 += " / Some more text";

	cout << "String 1 '" << s1 <<  "'" << endl;
	cout << endl;

	// Searching 
	int pos = s1.find_first_of("/");
	int len = s1.size() - pos;

	// Sub-string
	string s4 = s1.substr(pos, len);

	cout << "String 4 '" << s4 <<  "'" << endl;

	// Printing using C printf function.
	printf("String s4 is '%s'\n", s4.c_str());

} 

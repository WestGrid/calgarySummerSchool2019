#include <iostream>
#include <string>
using namespace std;

void do_something(int selector = 0){
	switch(selector){
		case 0: throw 'a';
		case 1: throw 1;	
		case 2: throw 2;	
		case 3: throw 3.0;
		case 4: throw string("Help!");
		default: return;
	}
}


int main(){

	try {
		do_something(4);
	}
	catch(int ex) { cout << "Int exception (" << ex << ")" << endl; }

	catch(double ex) { cout << "Double exception (" << ex << ")" << endl; }

	catch(const string& ex) { cout << "String exception (" << ex << ")" << endl; }
	
	catch(...) { cout << "Unknown exception (...)" << endl; }

	cout << "Success." << endl;
} 

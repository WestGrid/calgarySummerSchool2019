#include <iostream>
#include <cmath>

using namespace std;
// C++ templates.

int half(int x) { return x / 2; }
double half(double x) { return x / 2; }

// Function template.
template<class cType> cType half(const cType& x) { return x / cType(2); }

// Template specialization.
template<> string half<string>(const string& x) { return x.substr(0, x.length() / 2); }


// Class template.
template<class cType> class array10 {
private:
	cType xx[10];
	int n;
public:
	cType& operator[](int i) { return xx[i]; }
};

int main(){


	int k = -6;
	double a = -3.14;
	string s = "long-string";

	//cout << "k = " << k << ", half(k) = " << half(k) << endl;
	//cout << "a = " << a << ", half(a) = " << half(a) << endl;

	cout << "k = " << k << ", half(k) = " << half<int>(k) << endl;
	cout << "a = " << a << ", half(a) = " << half<double>(a) << endl;
	cout << "s = " << s << ", half(s) = " << half<string>(s) << endl;
	cout << endl;

	array10<float> xx;

	xx[5] = 5.5;
	cout << "xx[5] = " << xx[5] << endl;

	array10<int> ii;

	ii[5] = 5.5;
	cout << "ii[5] = " << ii[5] << endl;

}


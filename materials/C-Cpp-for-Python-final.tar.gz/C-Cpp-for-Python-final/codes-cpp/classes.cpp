#include <iostream>

using namespace std;
// Classes.

class vector3d {
public:
	double x, y, z;

	vector3d() {}
	vector3d(double vx): x(vx), y(vx), z(vx) {}
	vector3d(double vx, double vy, double vz): x(vx), y(vy), z(vz) {}

};


int main(){
	// Objects of double are created using constructors.
	double x, y(2.72), z = 3.14;

	// Object cout of output scream class
	// Objects x, y, z of double class;
	// Object endl of manipulator class.
	cout << "x = " << x << endl;
	cout << "y = " << y << endl;
	cout << "z = " << z << endl;
	cout << endl;

	int i(0), j(10), k;
	bool condition(true), flag(false);

	cout << "i, j, k = " << i << ", " << j << ", " << k << endl;
	cout << endl;

	cout << "Condition = " << condition << endl;
	cout << "Flag = " << flag << endl;
	cout << endl;

	vector3d v1;
	cout << "v1 = [" << v1.x << ", " << v1.y << ", " << v1.z << "]" << endl;

	vector3d v2(5.5);
	vector3d v3(1.1, 2.2, 3.3);
	vector3d v4(v2);

	cout << "v2 = [" << v2.x << ", " << v2.y << ", " << v2.z << "]" << endl;
	cout << "v3 = [" << v3.x << ", " << v3.y << ", " << v3.z << "]" << endl;
	cout << "v4 = [" << v4.x << ", " << v4.y << ", " << v4.z << "]" << endl;
	cout << endl;

	v1 = v3;
	cout << "v1 = [" << v1.x << ", " << v1.y << ", " << v1.z << "]" << endl;
} 

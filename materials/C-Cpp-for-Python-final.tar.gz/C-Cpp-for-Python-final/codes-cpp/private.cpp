#include <iostream>

using namespace std;
// Classes. Private members.

namespace my_classes {

class vector3d {
private:
	// Nobody will be able to access these outside of the class.
	// This is the implementation details.
	double _x, _y, _z;

	// Could be
	//double xx[3];
	//double *xp;
public:
	//This is the public interface of the class.
	vector3d() {}
	vector3d(double vx): _x(vx), _y(vx), _z(vx) {}
	vector3d(double vx, double vy, double vz): _x(vx), _y(vy), _z(vz) {}

	// Access methods:
	double x() const { return _x; }
	double y() const { return _y; }
	double z() const { return _z; }

	void x(double v) { _x = v; }
	void y(double v) { _y = v; }
	void z(double v) { _z = v; }
};

} // end of namespace my_classes.


using namespace my_classes;

int main(){

	vector3d v1;
	cout << "v1 = [" << v1.x() << ", " << v1.y() << ", " << v1.z() << "]" << endl;

	vector3d v2(5.5);
	vector3d v3(1.1, 2.2, 3.3);
	vector3d v4(v2);

	cout << "v2 = [" << v2.x() << ", " << v2.y() << ", " << v2.z() << "]" << endl;
	cout << "v3 = [" << v3.x() << ", " << v3.y() << ", " << v3.z() << "]" << endl;
	cout << "v4 = [" << v4.x() << ", " << v4.y() << ", " << v4.z() << "]" << endl;
	cout << endl;

	v1 = v3;
	cout << "v1 = [" << v1.x() << ", " << v1.y() << ", " << v1.z() << "]" << endl;
} 

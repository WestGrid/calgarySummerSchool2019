#include <iostream>

using namespace std;
// Our first C++ program. C++ style.

int main(){
	cout << "Hello World!" << endl;
} 

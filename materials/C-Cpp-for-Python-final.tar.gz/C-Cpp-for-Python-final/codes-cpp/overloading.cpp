#include <iostream>
#include <cmath>

using namespace std;
// Overloading. Polimorphism in C++.

namespace my_classes {

class vector3d {
private:
	double _x, _y, _z;

public:
	vector3d() {}
	vector3d(double vx): _x(vx), _y(vx), _z(vx) {}
	vector3d(double vx, double vy, double vz): _x(vx), _y(vy), _z(vz) {}

	double x() const { return _x; }
	double y() const { return _y; }
	double z() const { return _z; }

	void x(double v) { _x = v; }
	void y(double v) { _y = v; }
	void z(double v) { _z = v; }

	double dot(const vector3d& v2) const { return _x * v2._x + _y * v2._y + _z * v2._z; }
	double abs() const { return sqrt(dot(*this)); }

	void scale(double c) { _x *= c; _y *= c; _z *= c; }
	void normalize() { double c = 1.0 / abs(); scale(c); }

	// Overload unary minus operator.
	vector3d operator-() const { return vector3d(-_x, -_y, -_z); }

	// Overload += and -= operators.
	void operator+=(const vector3d& v) { _x += v._x; _y += v._y; _z += v._z; }
	void operator-=(const vector3d& v) { *this += (-v); }

	// Overload binary + operator
	vector3d operator+(const vector3d& v) const { vector3d r(*this); r += v; return r; }

	// Overload *= operator for a scalar and vector versions.
	void operator*=(double c) { scale(c); }
	void operator*=(const vector3d& v) { _x *= v._x; _y *= v._y; _z *= v._z; }

	// Overload binary * operators.
	vector3d operator*(double c) { vector3d r(*this); r *= c; return r; }
	vector3d operator*(const vector3d& v) { vector3d r(*this); r *= v; return r; }
	
	// Overload indexing operator.
	double operator[] (int i) { 
		switch(i){ 
			case 0: return _x;
		      	case 1: return _y;
		      	default: return _z; 
		} 
	}
};

// Overload streaming operator function. Cannot be a member of vector3d.
ostream& operator<< (ostream& os, const vector3d& v) { 
	os << "vector[" << v.x() << ", " << v.y() << ", " << v.z() << "]"; 
	return os;
}

// Overload * operator function. Cannot be a member of vector3d.
vector3d operator*(double c, const vector3d& v) { vector3d r(v); return r * c; }

} // end of namespace my_classes.

using namespace my_classes;

int main(){

	vector3d v1(1), v2(2), v3(3);

	cout << "v1 = " << v1 << endl;
	cout << "v2 = " << v2 << endl;
	cout << "v3 = " << v3 << endl;
	cout << endl;

	vector3d v4;
	v4 = v1 + v3;

	cout << "v4 = " << v4 << endl;
	cout << "-v4 = " << -v4 << endl;
	cout << endl;

	v4 += v1;
	cout << "v4 = " << v4 << endl;

	v4 -= v1;
	cout << "v4 = " << v4 << endl;
	cout << endl;

	v4 = v1 * 2;
	cout << "v4 = " << v4 << endl;
	v4 = 2 * v4;
	cout << "v4 = " << v4 << endl;
	cout << endl;
} 

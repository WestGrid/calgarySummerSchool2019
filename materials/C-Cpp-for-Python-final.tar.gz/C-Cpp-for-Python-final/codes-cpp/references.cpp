#include <iostream>

using namespace std;
// C++ references. 

// By value version.
void double_that(double x) { x *= 2.; }

// By pointer version.
void double_that(double *xp) { *xp *= 2.; }

// By reference version.
void double_that_ref(double& x) { x *= 2.; }

int main(){

	double x(4.0); 
	cout << "x = " << x << endl << endl;

	double_that(x);
	cout << "x = " << x << endl << endl;

	double_that(&x);
	cout << "x = " << x << endl << endl;

	double_that_ref(x);
	cout << "x = " << x << endl << endl;
} 

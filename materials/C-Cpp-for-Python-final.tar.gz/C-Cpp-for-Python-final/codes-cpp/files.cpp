#include <iostream>
#include <fstream>

using namespace std;
// Reading a binary file in memory with C++.

int main(){
	// The flags: input, binary, at-the-end;
	ifstream file("hello.cpp", ios::in|ios::binary|ios::ate);

	// Check if we have actually opened the file.
	if(not file.is_open()) {
		cout << "Cannot open file. Exiting." << endl;
		return 1;
	}
	
	// Find out the size of the file.
	streampos size = file.tellg();
	// Allocate memory for the entire file. malloc(..) would work too.
	char *buffer = new char[size];

	// Rewind the file to the beginning and read it. The flag: to-the-beginning.
	file.seekg(0, ios::beg);
	file.read(buffer, size);

	// Do not need it any more.
	file.close();

	cout << "Read " << size << " bytes into memory." << endl;

	cout << "========================" << endl;
	cout << buffer << endl;
	cout << "========================" << endl;
	cout << endl;

	// Do not forget to free the memory.
	delete[] buffer;
} 

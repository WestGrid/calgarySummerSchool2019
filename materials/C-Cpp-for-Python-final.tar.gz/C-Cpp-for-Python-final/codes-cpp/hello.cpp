#include <cstdio>

// Our first C++ program. C style.

int main(){
	printf("Hello World!\n");
} 

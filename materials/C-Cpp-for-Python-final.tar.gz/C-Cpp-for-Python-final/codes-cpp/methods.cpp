#include <iostream>
#include <cmath>

using namespace std;
// Classes. Encapsulating many methods.

namespace my_classes {

class vector3d {
private:
	double _x, _y, _z;

public:
	//This is the public interface of the class.
	vector3d() {}
	vector3d(double vx): _x(vx), _y(vx), _z(vx) {}
	vector3d(double vx, double vy, double vz): _x(vx), _y(vy), _z(vz) {}

	// Access methods:
	double x() const { return _x; }
	double y() const { return _y; }
	double z() const { return _z; }

	void x(double v) { _x = v; }
	void y(double v) { _y = v; }
	void z(double v) { _z = v; }

	double dot(const vector3d& v2) const { return _x * v2._x + _y * v2._y + _z * v2._z; }
	double abs() const { return sqrt(dot(*this)); }

	void scale(double c) { _x *= c; _y *= c; _z *= c; }
	void normalize() { double c = 1.0 / abs(); scale(c); }
};

} // end of namespace my_classes.


using namespace my_classes;

int main(){

	vector3d v1(1);
	cout << "v1 = [" << v1.x() << ", " << v1.y() << ", " << v1.z() << "]" << endl;
	cout << "abs(v1) = " << v1.abs() << endl;
	cout << endl;
	
	v1.normalize();
	cout << "v1 = [" << v1.x() << ", " << v1.y() << ", " << v1.z() << "]" << endl;
	cout << "abs(v1) = " << v1.abs() << endl;
	cout << endl;
} 

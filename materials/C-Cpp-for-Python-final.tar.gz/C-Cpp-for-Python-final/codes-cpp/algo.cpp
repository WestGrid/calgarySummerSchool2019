#include <iostream>
#include<vector>
#include<algorithm>

using namespace std;
// STL algorithm templates.

int main(){
	// Initialize vector from C-array.
	double xx[] = {3.3, 1.1, 2.2, 5.5, 9.9, 7.7};
	vector<double> values(begin(xx), end(xx));

	// Print values.
	for(int i = 0; i < values.size(); i++)
		cout << i << "  " << values[i] << endl;
	cout << endl;

	// Sorting
	sort(values.begin(), values.end());

	for(int i = 0; i < values.size(); i++)
		cout << i << "  " << values[i] << endl;
	cout << endl;

	// Reversing
	reverse(values.begin(), values.end());

	for(int i = 0; i < values.size(); i++)
		cout << i << "  " << values[i] << endl;
	cout << endl;

	// Min / Max element. Note dereferencing of the iterators.
	cout << "Max value = " << *max_element(values.begin(), values.end()) << endl;
	cout << "Min value = " << *min_element(values.begin(), values.end()) << endl;
} 

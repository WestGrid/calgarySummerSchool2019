#include <iostream>
#include<string>
#include<vector>

using namespace std;
// STL Vector container class.

int main(){

	vector<int> ii, jj(10), kk(10, 1);
	int n(5);

	for(int i = 0; i < jj.size(); i++) jj[i] = i;

	ii = jj;

	cout << "ii.size = " << ii.size() << endl;

	cout << "ii.empty = " << ii.empty() << endl;

	ii[10] = n;
	int m = ii[10];

	cout << "ii[10] = " << ii[10] << endl;
	cout << "m = " << m << endl;

	ii.push_back(m);
	ii.push_back(n);

	ii.insert(ii.begin(), m);

	cout << "ii.size = " << ii.size() << endl;
	cout << "ii.front = " << ii.front() << endl;
	cout << "ii.back = " << ii.back() << endl;

	ii.pop_back();
	cout << "ii.size = " << ii.size() << endl;

	ii.erase(ii.begin() + 5);
	cout << "ii.size = " << ii.size() << endl;


	for(int i = 0; i < ii.size(); i++) 
		cout << i << "  " << ii[i] << endl;
} 
